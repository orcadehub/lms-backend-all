const { validationResult } = require('express-validator');
const Assessment = require('../models/Assessment');
const AssessmentQuestion = require('../models/AssessmentQuestion');
const ExcelJS = require('exceljs');

// Create assessment
const createAssessment = async (req, res) => {
  try {
    console.log('Create assessment request body:', req.body);
    
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      console.log('Assessment validation errors:', errors.array());
      return res.status(400).json({ errors: errors.array() });
    }

    const { title, description, type, duration, difficulty, questions, batches, tenantId } = req.body;
    const finalTenantId = tenantId || req.user.tenantId || req.user.assignedTenants?.[0];

    // Handle 'all' batches case
    let batchIds = [];
    if (batches === 'all') {
      const Batch = require('../models/Batch');
      const allBatches = await Batch.find({ tenant: finalTenantId });
      batchIds = allBatches.map(batch => batch._id);
    } else {
      batchIds = Array.isArray(batches) ? batches : [batches];
    }
    
    const assessment = new Assessment({
      title,
      description,
      type,
      duration,
      difficulty,
      questions,
      batches: batchIds,
      createdBy: req.user.id,
      tenantId: finalTenantId,
      status: 'draft',
      maxTabSwitches: req.body.maxTabSwitches || 3
    });

    await assessment.save();
    await assessment.populate('questions');
    
    res.status(201).json({ message: 'Assessment created successfully', assessment });
  } catch (error) {
    console.error('Error creating assessment:', error);
    res.status(500).json({ message: 'Error creating assessment', error: error.message });
  }
};

// Get all assessments
const getAssessments = async (req, res) => {
  try {
    const { tenantId } = req.query;
    const filter = tenantId ? { tenantId } : {};
    const assessments = await Assessment.find(filter)
      .populate('questions', '_id')
      .populate('frontendQuestions', '_id')
      .populate('quizQuestions', '_id')
      .populate('mongodbPlaygroundQuestions', '_id')
      .populate('createdBy', 'name')
      .populate('batches', 'name')
      .select('+startTime')
      .sort({ createdAt: -1 });
    
    const assessmentsWithCounts = assessments.map(assessment => {
      const assessmentData = assessment.toObject();
      const questionCounts = {
        programming: assessment.questions?.length || 0,
        frontend: assessment.frontendQuestions?.length || 0,
        quiz: assessment.quizQuestions?.length || 0,
        mongodb: assessment.mongodbPlaygroundQuestions?.length || 0
      };
      questionCounts.coding = questionCounts.programming + questionCounts.frontend + questionCounts.mongodb;
      
      assessmentData.questionCounts = questionCounts;
      assessmentData.codingQuestionCount = questionCounts.coding;
      assessmentData.quizQuestionCount = questionCounts.quiz;
      assessmentData.totalQuestionCount = assessmentData.codingQuestionCount + questionCounts.quiz;
      
      return assessmentData;
    });

    res.json(assessmentsWithCounts);
  } catch (error) {
    console.error('Error fetching assessments:', error);
    res.status(500).json({ message: 'Error fetching assessments', error: error.message });
  }
};

// Get assessment by ID
const getAssessmentById = async (req, res) => {
  try {
    const { id } = req.params;
    const assessment = await Assessment.findById(id)
      .populate('questions')
      .populate('quizQuestions')
      .populate('frontendQuestions')
      .populate('mongodbPlaygroundQuestions')
      .populate('createdBy', 'name')
      .select('+startTime +showKeyInsights +showAlgorithmSteps +type');
    
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    const assessmentData = assessment.toObject();
    const questionCounts = {
      programming: assessment.questions?.length || 0,
      frontend: assessment.frontendQuestions?.length || 0,
      quiz: assessment.quizQuestions?.length || 0,
      mongodb: assessment.mongodbPlaygroundQuestions?.length || 0
    };
    questionCounts.coding = questionCounts.programming + questionCounts.frontend + questionCounts.mongodb;
    
    assessmentData.questionCounts = questionCounts;
    assessmentData.codingQuestionCount = questionCounts.coding;
    assessmentData.quizQuestionCount = questionCounts.quiz;
    assessmentData.totalQuestionCount = assessmentData.codingQuestionCount + questionCounts.quiz;
    
    res.json(assessmentData);
  } catch (error) {
    console.error('Error fetching assessment:', error);
    res.status(500).json({ message: 'Error fetching assessment', error: error.message });
  }
};

// Update assessment
const updateAssessment = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, duration, questions, batches, status } = req.body;

    const assessment = await Assessment.findByIdAndUpdate(
      id,
      { title, description, duration, questions, batches, status },
      { new: true, runValidators: true }
    ).populate('questions');
    
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    res.json({ message: 'Assessment updated successfully', assessment });
  } catch (error) {
    console.error('Error updating assessment:', error);
    res.status(500).json({ message: 'Error updating assessment', error: error.message });
  }
};

// Delete assessment
const deleteAssessment = async (req, res) => {
  try {
    const { id } = req.params;
    
    const assessment = await Assessment.findByIdAndDelete(id);
    
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    // Delete all attempts for this assessment
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    await AssessmentAttempt.deleteMany({ assessment: id });
    
    res.json({ message: 'Assessment deleted successfully' });
  } catch (error) {
    console.error('Error deleting assessment:', error);
    res.status(500).json({ message: 'Error deleting assessment', error: error.message });
  }
};

// Go live assessment
const goLiveAssessment = async (req, res) => {
  try {
    const { id } = req.params;
    const { startTime } = req.body;
    
    const assessment = await Assessment.findByIdAndUpdate(
      id,
      { 
        status: 'active',
        startTime: startTime ? new Date(startTime) : new Date()
      },
      { new: true }
    );
    
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }

    res.json({ message: 'Assessment is now live', assessment });
  } catch (error) {
    console.error('Error going live with assessment:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Update assessment settings
const updateAssessmentTime = async (req, res) => {
  try {
    console.log('Update assessment request body:', req.body);
    const { id } = req.params;
    const { startTime, earlyStartBuffer, maxTabSwitches, status, allowedIPs, allowedLanguages, duration, showKeyInsights, showAlgorithmSteps } = req.body;
    
    const updateData = {
      earlyStartBuffer: earlyStartBuffer || 0
    };
    
    if (startTime) {
      updateData.startTime = new Date(startTime);
    }
    
    if (maxTabSwitches !== undefined) {
      updateData.maxTabSwitches = maxTabSwitches;
    }
    
    if (status) {
      updateData.status = status;
    }
    
    if (duration !== undefined && duration >= 30 && duration <= 300) {
      updateData.duration = duration;
    }
    
    if (allowedIPs !== undefined) {
      updateData.allowedIPs = Array.isArray(allowedIPs) ? allowedIPs : [allowedIPs];
      console.log('Setting allowedIPs to:', updateData.allowedIPs);
    }
    
    if (allowedLanguages !== undefined) {
      updateData.allowedLanguages = Array.isArray(allowedLanguages) ? allowedLanguages : [allowedLanguages];
      console.log('Setting allowedLanguages to:', updateData.allowedLanguages);
    }
    
    if (showKeyInsights !== undefined) {
      updateData.showKeyInsights = showKeyInsights;
    }
    
    if (showAlgorithmSteps !== undefined) {
      updateData.showAlgorithmSteps = showAlgorithmSteps;
    }
    
    console.log('Final update data:', updateData);
    const assessment = await Assessment.findByIdAndUpdate(id, updateData, { new: true });
    
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    // Save again to ensure allowedIPs and allowedLanguages are persisted
    if (allowedIPs !== undefined) {
      assessment.allowedIPs = allowedIPs;
    }
    if (allowedLanguages !== undefined) {
      assessment.allowedLanguages = allowedLanguages;
    }
    if (allowedIPs !== undefined || allowedLanguages !== undefined) {
      await assessment.save();
    }
    
    // Emit real-time update to all connected clients
    const io = req.app.get('io');
    if (io) {
      console.log('Emitting assessment-updated event for assessment:', id);
      io.emit('assessment-updated', { assessmentId: id, assessment });
    }
    
    console.log('Updated assessment allowedIPs:', assessment.allowedIPs);
    res.json({ message: 'Assessment updated successfully', assessment });
  } catch (error) {
    console.error('Error updating assessment:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Get assessment attempts for instructor monitoring
const getAssessmentAttempts = async (req, res) => {
  try {
    const { id } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    const Student = require('../models/Student');
    
    const attempts = await AssessmentAttempt.find({ assessment: id })
      .populate('student', 'name email')
      .sort({ startedAt: -1 });
    
    const formattedAttempts = attempts.map(attempt => ({
      _id: attempt._id,
      studentId: attempt.student?._id,
      studentName: attempt.student?.name,
      studentEmail: attempt.student?.email,
      attemptStatus: attempt.attemptStatus,
      startedAt: attempt.startedAt,
      completedAt: attempt.completedAt,
      timeUsedSeconds: attempt.timeUsedSeconds,
      tabSwitchCount: attempt.tabSwitchCount || 0,
      fullscreenExitCount: attempt.fullscreenExitCount || 0,
      submissionReason: attempt.submissionReason,
      quizPercentage: attempt.quizPercentage || 0,
      programmingPercentage: attempt.programmingPercentage || 0,
      frontendPercentage: attempt.frontendPercentage || 0,
      mongodbPercentage: attempt.mongodbPercentage || 0,
      overallPercentage: attempt.overallPercentage || 0
    }));
    
    res.json(formattedAttempts);
  } catch (error) {
    console.error('Error fetching assessment attempts:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Handle student actions (resume, retake, terminate)
const handleStudentAction = async (req, res) => {
  try {
    const { attemptId, action } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    
    const attempt = await AssessmentAttempt.findById(attemptId);
    if (!attempt) {
      return res.status(404).json({ message: 'Attempt not found' });
    }
    
    switch (action) {
      case 'resume':
        attempt.attemptStatus = 'RESUME_ALLOWED';
        break;
      case 'retake':
        attempt.attemptStatus = 'RETAKE_ALLOWED';
        attempt.lastExecutedCode = {}; // Clear last executed code
        attempt.successfulCodes = {}; // Clear successful codes
        attempt.questionPercentages = {}; // Clear question percentages
        attempt.programmingPercentage = 0; // Reset programming percentage
        attempt.quizPercentage = 0; // Reset quiz percentage
        attempt.overallPercentage = 0; // Reset overall percentage
        attempt.tabSwitchCount = 0; // Reset tab switches
        attempt.fullscreenExitCount = 0; // Reset fullscreen exits
        attempt.quizAnswers = {}; // Clear quiz answers
        break;
      case 'terminate':
        attempt.attemptStatus = 'TERMINATED';
        attempt.completedAt = new Date();
        attempt.submissionReason = 'INSTRUCTOR_TERMINATED';
        break;
      default:
        return res.status(400).json({ message: 'Invalid action' });
    }
    
    await attempt.save();
    res.json({ message: `${action} successful`, attempt });
  } catch (error) {
    console.error(`Error with ${action}:`, error);
    res.status(500).json({ message: `Failed to ${action}`, error: error.message });
  }
};

// Export assessment results to Excel
const exportAssessmentResults = async (req, res) => {
  try {
    const { id } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    
    const assessment = await Assessment.findById(id).populate('questions');
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    const attempts = await AssessmentAttempt.find({ assessment: id })
      .populate('student', 'name email')
      .sort({ createdAt: -1 });
    
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Assessment Results');
    
    // Define base columns
    const baseColumns = [
      { header: 'Name', key: 'name', width: 20 },
      { header: 'Roll Number', key: 'rollNumber', width: 20 },
      { header: 'Email', key: 'email', width: 25 },
      { header: 'Quiz Percentage', key: 'quizPercentage', width: 15 },
      { header: 'Programming Percentage', key: 'programmingPercentage', width: 20 },
      { header: 'Overall Percentage', key: 'overallPercentage', width: 18 },
      { header: 'Time Used', key: 'timeUsed', width: 12 },
      { header: 'Tab Switches', key: 'tabSwitches', width: 12 },
      { header: 'Fullscreen Exits', key: 'fullscreenExits', width: 15 },
      { header: 'Submission Reason', key: 'submissionReason', width: 18 },
      { header: 'Total Questions', key: 'totalQuestions', width: 15 },
      { header: 'Attempted', key: 'attempted', width: 12 },
      { header: 'Unattempted', key: 'unattempted', width: 12 }
    ];
    
    // Add columns for each question
    const questionColumns = assessment.questions.map((question, index) => ({
      header: `Q${index + 1}: ${question.title}`,
      key: `question_${question._id}`,
      width: 15
    }));
    
    const endColumns = [
      { header: 'Start IP', key: 'startIP', width: 15 },
      { header: 'End IP', key: 'endIP', width: 15 },
      { header: 'Status', key: 'status', width: 15 },
      { header: 'Started At', key: 'startedAt', width: 20 },
      { header: 'Completed At', key: 'completedAt', width: 20 },
      { header: 'Resume Count', key: 'resumeCount', width: 12 },
      { header: 'Retake Count', key: 'retakeCount', width: 12 },
      { header: 'Session Data', key: 'sessionData', width: 50 }
    ];
    
    worksheet.columns = [...baseColumns, ...questionColumns, ...endColumns];
    
    // Style header row
    worksheet.getRow(1).font = { bold: true };
    worksheet.getRow(1).fill = {
      type: 'pattern',
      pattern: 'solid',
      fgColor: { argb: 'FFE0E0E0' }
    };
    
    // Sort attempts by overall percentage (descending), then by tab switches (ascending), then by fullscreen exits (ascending), then by time used (ascending), then alphabetically by name
    attempts.sort((a, b) => {
      const percentageA = a.overallPercentage || 0;
      const percentageB = b.overallPercentage || 0;
      
      if (percentageB !== percentageA) {
        return percentageB - percentageA; // Higher percentage first
      }
      
      const tabSwitchesA = a.tabSwitchCount || 0;
      const tabSwitchesB = b.tabSwitchCount || 0;
      
      if (tabSwitchesA !== tabSwitchesB) {
        return tabSwitchesA - tabSwitchesB; // Lower tab switches first
      }
      
      const fullscreenExitsA = a.fullscreenExitCount || 0;
      const fullscreenExitsB = b.fullscreenExitCount || 0;
      
      if (fullscreenExitsA !== fullscreenExitsB) {
        return fullscreenExitsA - fullscreenExitsB; // Lower fullscreen exits first
      }
      
      const timeUsedA = a.timeUsedSeconds || 0;
      const timeUsedB = b.timeUsedSeconds || 0;
      
      if (timeUsedA !== timeUsedB) {
        return timeUsedA - timeUsedB; // Lower time used first
      }
      
      // Alphabetical order by name
      const nameA = a.student?.name || 'Unknown';
      const nameB = b.student?.name || 'Unknown';
      return nameA.localeCompare(nameB);
    });
    
    // Add data rows
    attempts.forEach(attempt => {
      const totalQuestions = assessment.questions.length;
      const attempted = Object.keys(attempt.successfulCodes || {}).length;
      const unattempted = totalQuestions - attempted;
      const overallPercentage = attempt.overallPercentage || 0;
      
      const rowData = {
        name: attempt.student?.name || 'Unknown',
        rollNumber: attempt.student?.email ? attempt.student.email.split('@')[0] : 'N/A',
        email: attempt.student?.email || 'N/A',
        quizPercentage: (attempt.quizPercentage || 0).toFixed(2) + '%',
        programmingPercentage: (attempt.programmingPercentage || 0).toFixed(2) + '%',
        overallPercentage: overallPercentage.toFixed(2) + '%',
        timeUsed: attempt.timeUsedSeconds ? Math.floor(attempt.timeUsedSeconds / 60) + 'm ' + (attempt.timeUsedSeconds % 60) + 's' : '0m 0s',
        tabSwitches: attempt.tabSwitchCount || 0,
        fullscreenExits: attempt.fullscreenExitCount || 0,
        submissionReason: attempt.submissionReason || 'N/A',
        totalQuestions,
        attempted,
        unattempted,
        startIP: attempt.sessionData?.startIP || 'N/A',
        endIP: attempt.sessionData?.endIP || attempt.sessionData?.startIP || 'N/A',
        status: attempt.attemptStatus || 'N/A',
        startedAt: attempt.startedAt ? new Date(attempt.startedAt).toLocaleString() : 'N/A',
        completedAt: attempt.completedAt ? new Date(attempt.completedAt).toLocaleString() : 'N/A',
        resumeCount: attempt.resumeCount || 0,
        retakeCount: attempt.retakeCount || 0,
        sessionData: [
          attempt.sessionData?.systemInfo?.map((info, index) => 
            `Session ${index + 1}: Browser: ${info.userAgent} | Platform: ${info.platform} | Screen: ${info.screenResolution} | Timezone: ${info.timezone} | Timestamp: ${new Date(info.timestamp).toLocaleString()}`
          ).join(' || ') || '',
          attempt.sessionData?.sessionStartTime ? `Session Start: ${new Date(attempt.sessionData.sessionStartTime).toLocaleString()}` : '',
          attempt.sessionData?.sessionEndTime ? `Session End: ${new Date(attempt.sessionData.sessionEndTime).toLocaleString()}` : ''
        ].filter(info => info).join(' | ')
      };
      
      // Add question-wise percentages
      assessment.questions.forEach(question => {
        const questionPercentage = attempt.questionPercentages?.[question._id] || 0;
        rowData[`question_${question._id}`] = questionPercentage.toFixed(2) + '%';
      });
      
      worksheet.addRow(rowData);
    });
    
    // Set response headers
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="${assessment.title}_results.xlsx"`);
    
    // Write to response
    await workbook.xlsx.write(res);
    res.end();
  } catch (error) {
    console.error('Error exporting assessment results:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Expire assessment timer - mark all IN_PROGRESS attempts as COMPLETED
const expireAssessmentTimer = async (req, res) => {
  try {
    const { id } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    
    // Find all attempts that should be completed for this assessment
    const attemptsToComplete = await AssessmentAttempt.find({ 
      assessment: id, 
      attemptStatus: { $in: ['IN_PROGRESS', 'RESUME_ALLOWED', 'RETAKE_ALLOWED'] }
    });
    
    if (attemptsToComplete.length === 0) {
      return res.json({ message: 'No attempts found to complete', updatedCount: 0 });
    }
    
    // Update each attempt individually to ensure proper time calculation
    let updatedCount = 0;
    for (const attempt of attemptsToComplete) {
      const timeUsed = Math.floor((new Date() - new Date(attempt.startedAt)) / 1000);
      await AssessmentAttempt.findByIdAndUpdate(attempt._id, {
        attemptStatus: 'COMPLETED',
        submissionReason: 'TIME_UP',
        completedAt: new Date(),
        timeUsedSeconds: timeUsed
      });
      updatedCount++;
    }
    
    res.json({ 
      message: 'Assessment timer expired successfully', 
      updatedCount: updatedCount,
      attemptIds: attemptsToComplete.map(a => a._id)
    });
  } catch (error) {
    console.error('Error expiring assessment timer:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Add quiz question to assessment
const addQuizQuestion = async (req, res) => {
  try {
    const { id } = req.params;
    const { questionId } = req.body;
    
    const assessment = await Assessment.findById(id);
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    if (!assessment.quizQuestions) {
      assessment.quizQuestions = [];
    }
    
    if (!assessment.quizQuestions.includes(questionId)) {
      assessment.quizQuestions.push(questionId);
      await assessment.save();
    }
    
    await assessment.populate('quizQuestions');
    res.json({ message: 'Quiz question added successfully', assessment });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Remove quiz question from assessment
const removeQuizQuestion = async (req, res) => {
  try {
    const { id, questionId } = req.params;
    
    const assessment = await Assessment.findById(id);
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    if (assessment.quizQuestions) {
      assessment.quizQuestions = assessment.quizQuestions.filter(q => q.toString() !== questionId);
      await assessment.save();
    }
    
    await assessment.populate('quizQuestions');
    res.json({ message: 'Quiz question removed successfully', assessment });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Add MongoDB question to assessment
const addMongoDBQuestion = async (req, res) => {
  try {
    const { id } = req.params;
    const { questionId } = req.body;
    
    const assessment = await Assessment.findById(id);
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    if (!assessment.mongodbPlaygroundQuestions) {
      assessment.mongodbPlaygroundQuestions = [];
    }
    
    if (!assessment.mongodbPlaygroundQuestions.includes(questionId)) {
      assessment.mongodbPlaygroundQuestions.push(questionId);
      await assessment.save();
    }
    
    await assessment.populate('mongodbPlaygroundQuestions');
    res.json({ message: 'MongoDB question added successfully', assessment });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Remove MongoDB question from assessment
const removeMongoDBQuestion = async (req, res) => {
  try {
    const { id, questionId } = req.params;
    
    const assessment = await Assessment.findById(id);
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    if (assessment.mongodbPlaygroundQuestions) {
      assessment.mongodbPlaygroundQuestions = assessment.mongodbPlaygroundQuestions.filter(q => q.toString() !== questionId);
      await assessment.save();
    }
    
    await assessment.populate('mongodbPlaygroundQuestions');
    res.json({ message: 'MongoDB question removed successfully', assessment });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Add frontend question to assessment
const addFrontendQuestion = async (req, res) => {
  try {
    const { id } = req.params;
    const { questionId } = req.body;
    
    const assessment = await Assessment.findById(id);
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    if (!assessment.frontendQuestions) {
      assessment.frontendQuestions = [];
    }
    
    if (!assessment.frontendQuestions.includes(questionId)) {
      assessment.frontendQuestions.push(questionId);
      await assessment.save();
    }
    
    await assessment.populate('frontendQuestions');
    res.json({ message: 'Frontend question added successfully', assessment });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Remove frontend question from assessment
const removeFrontendQuestion = async (req, res) => {
  try {
    const { id, questionId } = req.params;
    
    const assessment = await Assessment.findById(id);
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    if (assessment.frontendQuestions) {
      assessment.frontendQuestions = assessment.frontendQuestions.filter(q => q.toString() !== questionId);
      await assessment.save();
    }
    
    await assessment.populate('frontendQuestions');
    res.json({ message: 'Frontend question removed successfully', assessment });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Mark all in-progress students as completed
const markAllInProgressCompleted = async (req, res) => {
  try {
    const { id } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    
    const result = await AssessmentAttempt.updateMany(
      { 
        assessment: id, 
        attemptStatus: { $in: ['IN_PROGRESS', 'RESUME_ALLOWED', 'RETAKE_ALLOWED'] }
      },
      {
        attemptStatus: 'COMPLETED',
        submissionReason: 'TIME_UP',
        completedAt: new Date()
      }
    );
    
    res.json({ 
      message: 'All students marked as completed', 
      count: result.modifiedCount 
    });
  } catch (error) {
    console.error('Error marking students as completed:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Mark all in-progress students as resume allowed
const markAllInProgressResume = async (req, res) => {
  try {
    const { id } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    
    const result = await AssessmentAttempt.updateMany(
      { 
        assessment: id, 
        attemptStatus: { $in: ['IN_PROGRESS', 'RETAKE_ALLOWED'] }
      },
      {
        attemptStatus: 'RESUME_ALLOWED',
        tabSwitchCount: 0
      }
    );
    
    res.json({ 
      message: 'All students marked as resume allowed', 
      count: result.modifiedCount 
    });
  } catch (error) {
    console.error('Error marking students as resume allowed:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Mark all in-progress students as retake allowed
const markAllInProgressRetake = async (req, res) => {
  try {
    const { id } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    
    const result = await AssessmentAttempt.updateMany(
      { 
        assessment: id, 
        attemptStatus: { $in: ['IN_PROGRESS', 'RESUME_ALLOWED'] }
      },
      {
        attemptStatus: 'RETAKE_ALLOWED',
        lastExecutedCode: {},
        successfulCodes: {},
        questionPercentages: {},
        programmingPercentage: 0,
        quizPercentage: 0,
        overallPercentage: 0,
        tabSwitchCount: 0,
        fullscreenExitCount: 0,
        quizAnswers: {}
      }
    );
    
    res.json({ 
      message: 'All students marked as retake allowed', 
      count: result.modifiedCount 
    });
  } catch (error) {
    console.error('Error marking students as retake allowed:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

const markAllCompletedResume = async (req, res) => {
  try {
    const { id } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    
    const result = await AssessmentAttempt.updateMany(
      { 
        assessment: id, 
        attemptStatus: 'COMPLETED'
      },
      {
        attemptStatus: 'RESUME_ALLOWED',
        tabSwitchCount: 0
      }
    );
    
    res.json({ 
      message: 'All completed students marked as resume allowed', 
      count: result.modifiedCount 
    });
  } catch (error) {
    console.error('Error marking completed students as resume allowed:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

const deleteAllAttempts = async (req, res) => {
  try {
    const { id } = req.params;
    const AssessmentAttempt = require('../models/AssessmentAttempt');
    
    const result = await AssessmentAttempt.deleteMany({ assessment: id });
    
    res.json({ 
      message: 'All attempts deleted successfully', 
      count: result.deletedCount 
    });
  } catch (error) {
    console.error('Error deleting attempts:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Add programming question to assessment
const addProgrammingQuestion = async (req, res) => {
  try {
    const { id } = req.params;
    const { questionId } = req.body;
    
    const assessment = await Assessment.findById(id);
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    if (!assessment.questions) {
      assessment.questions = [];
    }
    
    if (!assessment.questions.includes(questionId)) {
      assessment.questions.push(questionId);
      await assessment.save();
    }
    
    await assessment.populate('questions');
    res.json({ message: 'Programming question added successfully', assessment });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// Remove programming question from assessment
const removeProgrammingQuestion = async (req, res) => {
  try {
    const { id, questionId } = req.params;
    
    const assessment = await Assessment.findById(id);
    if (!assessment) {
      return res.status(404).json({ message: 'Assessment not found' });
    }
    
    if (assessment.questions) {
      assessment.questions = assessment.questions.filter(q => q.toString() !== questionId);
      await assessment.save();
    }
    
    await assessment.populate('questions');
    res.json({ message: 'Programming question removed successfully', assessment });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  createAssessment,
  getAssessments,
  getAssessmentById,
  updateAssessment,
  deleteAssessment,
  goLiveAssessment,
  updateAssessmentTime,
  getAssessmentAttempts,
  handleStudentAction,
  exportAssessmentResults,
  expireAssessmentTimer,
  addQuizQuestion,
  removeQuizQuestion,
  addFrontendQuestion,
  removeFrontendQuestion,
  addProgrammingQuestion,
  removeProgrammingQuestion,
  addMongoDBQuestion,
  removeMongoDBQuestion,
  markAllInProgressCompleted,
  markAllInProgressResume,
  markAllInProgressRetake,
  markAllCompletedResume,
  deleteAllAttempts
};